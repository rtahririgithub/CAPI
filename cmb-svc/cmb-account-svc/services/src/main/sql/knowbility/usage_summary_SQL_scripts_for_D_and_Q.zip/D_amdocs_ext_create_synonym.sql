
-- Start of DDL script for USAGE_UTILITY_PKG
-- Generated 29-Jul-03  10:44:27 am
-- from dkb1-AMDOCS_EXTD3:2 

-- Updated  Dec-18-2003 by Carlos Manjarres
-- To be executed by AMDOCS_EXTD[123] 

-- Synonym USAGE_UTILITY_PKG


CREATE SYNONYM market FOR TSDREF02.market
/
CREATE SYNONYM npa_nxx_lr FOR TSDREF02.npa_nxx_lr
/
-- End of DDL script for USAGE_UTILITY_PKG
