
-- Start of DDL script for USAGE_UTILITY_PKG
-- Generated 29-Jul-03  10:44:27 am
-- from dkb1-BASREAD3:2

-- Synonym USAGE_UTILITY_PKG

CREATE SYNONYM usage_utility_pkg
           FOR amdocs_extd3.usage_utility_pkg
/

-- End of DDL script for USAGE_UTILITY_PKG
