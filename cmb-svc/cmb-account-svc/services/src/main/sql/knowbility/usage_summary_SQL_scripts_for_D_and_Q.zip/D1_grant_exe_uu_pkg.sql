-- Created Dec-18-2003
-- To be executed as AMDOCS_EXTD1 


-- Grants for USAGE_UTILITY_PKG

GRANT EXECUTE ON usage_utility_pkg TO basread1
/

